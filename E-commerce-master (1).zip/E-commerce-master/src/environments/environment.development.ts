export const environment = {
  baseUrlAuth: `https://ecommerce.routemisr.com/api/v1/auth`,
  baseUrlData: `https://ecommerce.routemisr.com/api/v1`,
  baseUrlUser: `https://ecommerce.routemisr.com/api/v1`,
  payUrl: 'http://localhost:4200',
};
